# Weather Icons
*Version Beta 1 - August 3rd 2013*

In case you need an offline reference for what the icons look like or their class names, here they are.